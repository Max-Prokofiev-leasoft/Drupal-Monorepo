<?php

namespace Drupal\commerce_ginger\Interface;

interface PaymentMethodFormInterface
{
  public function prepareForm(array $form);
}
