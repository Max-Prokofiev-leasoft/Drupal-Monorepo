<?php
namespace Drupal\commerce_ginger\Redefiner;

use Drupal\commerce_ginger\PluginForm\AbstractPayment;

/**
 * Class AbstractPaymentRedefiner.
 *
 * This class for redefining AbstractPayment
 *
 * @package Drupal\commerce_ginger\Redefiner
 */

class AbstractPaymentRedefiner extends AbstractPayment
{
  // Here you can redefine all AbstractPayment functionality
}
